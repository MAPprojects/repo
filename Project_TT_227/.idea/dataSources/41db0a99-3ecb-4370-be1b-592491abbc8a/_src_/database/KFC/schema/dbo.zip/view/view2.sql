CREATE VIEW dbo.view2
AS
SELECT        dbo.AngajatiKFC.CNP_Angajat, dbo.AngajatiKFC.Nume, dbo.Departament.Nume AS Expr1
FROM            dbo.AngajatiKFC INNER JOIN
                         dbo.Departament ON dbo.AngajatiKFC.Departament = dbo.Departament.Nume
GO
