CREATE VIEW dbo.view3
AS
SELECT        dbo.AngajatiKFC.CNP_Angajat, dbo.AngajatiKFC.Nume, dbo.AngajatiKFC.Prenume, dbo.Departament.Nume AS Expr1
FROM            dbo.AngajatiKFC INNER JOIN
                         dbo.Departament ON dbo.AngajatiKFC.Departament = dbo.Departament.Nume
GROUP BY dbo.AngajatiKFC.CNP_Angajat, dbo.AngajatiKFC.Nume, dbo.AngajatiKFC.Prenume, dbo.Departament.Nume
GO
