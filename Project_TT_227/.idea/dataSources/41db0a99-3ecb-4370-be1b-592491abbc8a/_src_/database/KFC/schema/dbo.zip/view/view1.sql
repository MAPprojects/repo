CREATE VIEW dbo.view1
AS
SELECT        dbo.Produs.*
FROM            dbo.Produs
GO
