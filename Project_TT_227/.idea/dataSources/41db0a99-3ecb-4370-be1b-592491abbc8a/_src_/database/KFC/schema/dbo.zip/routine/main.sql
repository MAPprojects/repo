CREATE PROCEDURE main @Versiune INT
AS
BEGIN 
	DECLARE @VersiuneDB INT
	DECLARE @ProcName VARCHAR(50)
	DECLARE @Mesaj VARCHAR(255)
	DECLARE @VersiuneInitiala INT
	SET @VersiuneDB = (SELECT Versiune FROM VersiuneBD)
	SET @VersiuneInitiala = (SELECT Versiune FROM VersiuneBD)
	--IF (@Versiune <= 7)
	IF @Versiune <= 7 AND @Versiune >= 0
	BEGIN
	IF @VersiuneInitiala < @Versiune
	BEGIN
		WHILE ((SELECT @VersiuneDB) < @Versiune)
		BEGIN
			SET @ProcName = 'do_'+CONVERT(VARCHAR(5),((SELECT @VersiuneDB)+1))
			EXEC @ProcName
			UPDATE VersiuneBD
			SET Versiune = (SELECT @VersiuneDB)+1
			SET @VersiuneDB = (SELECT Versiune FROM VersiuneBD)
		END
		SET @Mesaj = 'S-a trecut de la versiunea ' + CONVERT(VARCHAR(5),(SELECT @VersiuneInitiala)) + ' la versiunea ' + CONVERT(VARCHAR(5),(SELECT @Versiune))
		PRINT @Mesaj
	END
	ELSE
	IF @VersiuneInitiala > @Versiune
	BEGIN
		WHILE ((SELECT @VersiuneDB) > @Versiune)
		BEGIN
			SET @ProcName = 'undo_'+CONVERT(VARCHAR(5),(SELECT @VersiuneDB))
			EXEC @ProcName
			UPDATE VersiuneBD
			SET Versiune = (SELECT @VersiuneDB)-1
			SET @VersiuneDB = (SELECT Versiune FROM VersiuneBD)
		END
		SET @Mesaj = 'S-a trecut de la versiunea ' + CONVERT(VARCHAR(5),(SELECT @VersiuneInitiala)) + ' la versiunea ' + CONVERT(VARCHAR(5),(SELECT @Versiune))
		PRINT @Mesaj
	END
	END
	ELSE
		PRINT 'Versiunea trebuie sa fie intre 0 si 7!'
END
GO
