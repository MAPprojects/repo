
CREATE PROCEDURE [dbo].[TableOperations]
@codRulareTest INT
AS
BEGIN

	DECLARE @nrInregistrari INT
	DECLARE @cont INT
	DECLARE @string VARCHAR(30)
	--SET @nrInregistrari=100
	--acum ne ocupam de primul tabel(1 cheie primara)
	SET @cont=1
	SELECT @nrInregistrari=NrRanduri FROM TesteTabele T WHERE CodTabel=1
	INSERT INTO RulariTesteTabele VALUES (@codRulareTest,1,GETDATE(),GETDATE())
	DELETE FROM evidentaHelestee
	WHILE @cont < @nrInregistrari
		BEGIN
			SET @string= 'Pasare' + CONVERT (VARCHAR(10), @cont)
			INSERT INTO pasare (codPasare,nume,specie,varsta) VALUES (@cont,@string,@string,@cont)
			SET @cont=@cont+1
		END	
	UPDATE RulariTesteTabele SET SeIncheieLa=GETDATE() WHERE CodTabel=1 AND CodRulareTest=@codRulareTest
	--ne ocupam de al doilea tabel(1 cheie primara si un fk)
	SET @cont=1
	SELECT @nrInregistrari=NrRanduri FROM TesteTabele T WHERE CodTabel=2
	INSERT INTO RulariTesteTabele VALUES (@codRulareTest,2,GETDATE(),GETDATE())
	WHILE @cont < @nrInregistrari
		BEGIN
			INSERT INTO helesteu (codHelesteu,codPasare,suprafata) VALUES (@cont,1,@cont)
			SET @cont=@cont+1
		END
	DELETE FROM helesteu
	UPDATE RulariTesteTabele SET SeIncheieLa=GETDATE() WHERE CodTabel=2 AND CodRulareTest=@codRulareTest
	--in final ne ocupam de ultimul tabel
	SELECT @nrInregistrari=NrRanduri FROM TesteTabele T WHERE CodTabel=3
	SET @cont=1
	INSERT INTO RulariTesteTabele VALUES (@codRulareTest,3,GETDATE(),GETDATE())
	DELETE FROM pasare
	WHILE @cont < @nrInregistrari
		BEGIN
			INSERT INTO evidentaHelestee (codPasare,codHelesteu) VALUES (@cont,@cont)
			SET @cont=@cont+1
		END
	UPDATE RulariTesteTabele SET SeIncheieLa=GETDATE() WHERE CodTabel=3 AND CodRulareTest=@codRulareTest
END
GO
