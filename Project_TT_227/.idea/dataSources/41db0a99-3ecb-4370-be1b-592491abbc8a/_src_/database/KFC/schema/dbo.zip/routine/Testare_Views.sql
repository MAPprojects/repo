
CREATE PROCEDURE [dbo].[Testare_Views]
@codRulareTest INT
AS
BEGIN
	INSERT INTO RulariTesteViewuri VALUES (@codRulareTest,1,GETDATE(),GETDATE())
	Select * FROM view1
	UPDATE RulariTesteViewuri SET SeIncheieLa=GETDATE() WHERE CodView=1 AND CodRulareTest=@codRulareTest

	INSERT INTO RulariTesteViewuri VALUES (@codRulareTest,2,GETDATE(),GETDATE())
	Select * FROM view2
	UPDATE RulariTesteViewuri SET SeIncheieLa=GETDATE() WHERE CodView=2 AND CodRulareTest=@codRulareTest

	INSERT INTO RulariTesteViewuri VALUES (@codRulareTest,3,GETDATE(),GETDATE())
	Select * FROM view3
	UPDATE RulariTesteViewuri SET SeIncheieLa=GETDATE() WHERE CodView=3 AND CodRulareTest=@codRulareTest
END
GO
