CREATE PROCEDURE proc2
AS
BEGIN
ALTER TABLE Telefon
ALTER COLUMN tip varchar(30)
PRINT 'S-a modificat coloana tip din Telefon de la varchar(20) la varchar(30)'
END
GO
