CREATE PROCEDURE proc1
AS
BEGIN
CREATE TABLE Telefon(
idMan int,
nrTel varchar(10) NOT NULL,
tip varchar(20))
PRINT 'S-a creat tabelul Telefon'
END
GO
