create procedure EvaluateView1
as
begin
select * from ViewGameMini
end
GO
