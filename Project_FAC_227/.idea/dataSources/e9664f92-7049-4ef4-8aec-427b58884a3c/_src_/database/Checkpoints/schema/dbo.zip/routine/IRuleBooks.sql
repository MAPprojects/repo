
create procedure IRuleBooks
@id int
as
begin
	insert into Boardgames
	values (@id,'a',10)
	insert into RuleBooks
	values (@id,'w',20,@id)
end
GO
