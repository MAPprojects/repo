CREATE PROCEDURE undo_proc6
AS
BEGIN
ALTER TABLE Telefon
DROP CONSTRAINT uniq_phone
PRINT 'S-a sters constrangerea UNIQUE de la idMan'
END
GO
