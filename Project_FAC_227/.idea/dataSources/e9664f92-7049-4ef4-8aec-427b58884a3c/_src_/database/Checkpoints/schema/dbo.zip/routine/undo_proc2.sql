CREATE PROCEDURE undo_proc2
AS
BEGIN
ALTER TABLE Telefon
ALTER COLUMN tip varchar(20)
PRINT 'S-a modificat coloana tip din Telefon inapoi la varchar(20)'
END
GO
