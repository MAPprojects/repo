CREATE PROCEDURE undo_proc3
AS
BEGIN
ALTER TABLE Telefon
DROP COLUMN provider_tel
PRINT 'S-a sters coloana provider_tel'
END
GO
