
create procedure EvaluateView2
as
begin
select * from ViewRuleBooks
end
GO
