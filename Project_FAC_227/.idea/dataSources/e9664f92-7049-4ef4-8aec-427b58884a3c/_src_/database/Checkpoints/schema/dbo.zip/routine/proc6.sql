CREATE PROCEDURE proc6
AS
BEGIN
ALTER TABLE Telefon
ADD CONSTRAINT uniq_phone UNIQUE(idMan)
PRINT 'S-a adaugat constrangerea UNIQUE la idMan'
END
GO
