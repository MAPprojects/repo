CREATE PROCEDURE undo_proc7
AS
BEGIN
ALTER TABLE Telefon
DROP CONSTRAINT fk_telefon
PRINT 'S-a sters legatura FK dintre Telefon si Managers'
END
GO
