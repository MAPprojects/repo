create procedure EvaluateView3
as
begin
select * from ViewTG
end


GO
