CREATE VIEW dbo.View_1
AS
SELECT        dbo.Minis.descriere, dbo.Boardgames.denumire, dbo.GameToMinis.idm
FROM            dbo.Boardgames INNER JOIN
                         dbo.GameToMinis ON dbo.Boardgames.idg = dbo.GameToMinis.idg INNER JOIN
                         dbo.Minis ON dbo.GameToMinis.idm = dbo.Minis.idm
GROUP BY dbo.Boardgames.denumire, dbo.GameToMinis.idm, dbo.Minis.descriere
GO
