CREATE VIEW dbo.ViewRuleBooks
AS
SELECT        titlu, idg
FROM            dbo.RuleBooks
GO
