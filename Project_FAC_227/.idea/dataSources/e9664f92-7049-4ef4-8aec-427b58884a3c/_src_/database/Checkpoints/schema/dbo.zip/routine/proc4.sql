CREATE PROCEDURE proc4
AS
BEGIN
ALTER TABLE Telefon
ADD CONSTRAINT telefon_def DEFAULT '07--------' FOR nrTel
PRINT 'S-a adaugat default 07-------- la nrTel'
END
GO
