create procedure IBoardgames
@id int
as
begin
	insert into Boardgames
	values (@id,'a',10)
end
GO
