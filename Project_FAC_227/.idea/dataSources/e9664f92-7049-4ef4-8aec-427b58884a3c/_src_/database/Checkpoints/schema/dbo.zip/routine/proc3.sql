CREATE PROCEDURE proc3
AS
BEGIN
ALTER TABLE Telefon
ADD provider_tel varchar(10)
PRINT 'S-a adaugat coloana provider_tel'
END
GO
