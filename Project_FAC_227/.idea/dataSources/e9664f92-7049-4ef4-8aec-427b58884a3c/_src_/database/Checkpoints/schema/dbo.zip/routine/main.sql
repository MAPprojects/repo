CREATE PROCEDURE [dbo].[main]
@vers INT
AS
BEGIN
	DECLARE @command varchar(50)
	DECLARE @curent INT
	SELECT TOP 1 @curent=nr FROM Versiune
	IF @vers <= 7 AND @vers >= 0
	BEGIN
			IF @vers>@curent
				BEGIN
				WHILE @vers>@curent
					BEGIN
					SET @curent=@curent +1
					SET @command='proc' + CONVERT(varchar(5),@curent)
					EXEC @command
					END
				END
			ELSE
				BEGIN
				WHILE @vers<@curent
					BEGIN
					SET @command='undo_proc' + CONVERT(varchar(5),@curent)
					SET @curent=@curent -1
					EXEC @command
					END
				END
			UPDATE Versiune
			SET nr=@curent
	END
	ELSE
		PRINT 'Versiune invalida'
		
	--	END
END
GO
