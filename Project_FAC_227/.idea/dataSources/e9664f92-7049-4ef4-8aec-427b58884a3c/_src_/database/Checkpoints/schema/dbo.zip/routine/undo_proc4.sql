CREATE PROCEDURE undo_proc4
AS
BEGIN
ALTER TABLE Telefon
DROP CONSTRAINT telefon_def
PRINT 'S-a sters default de la nrTel'
END
GO
