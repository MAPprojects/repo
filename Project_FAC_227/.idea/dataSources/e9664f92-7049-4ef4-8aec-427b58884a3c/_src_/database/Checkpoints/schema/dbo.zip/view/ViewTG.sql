CREATE VIEW dbo.ViewTG
AS
SELECT        dbo.Boardgames.denumire, dbo.Tournaments.premiu
FROM            dbo.Tournaments INNER JOIN
                         dbo.Boardgames ON dbo.Tournaments.idg = dbo.Boardgames.idg
GROUP BY dbo.Tournaments.premiu, dbo.Boardgames.denumire
GO
