CREATE procedure [dbo].[Deleting]
@idtab int, @idtest int
AS
begin
declare @nrRanduri int
declare @tabel varchar(30)

select @nrRanduri = NrRanduri
from TesteTabele
where CodTest = @idtest AND CodTabel = @idtab

select @tabel = nume
from Tabele
where CodTabel = @idtab 

declare @i int
set @i=21
set @tabel ='D'+@tabel

Exec @tabel
end
GO
