create procedure Inserting
@idtab int, @idtest int
AS
begin
declare @nrRanduri int
declare @tabel varchar(30)

select @nrRanduri = NrRanduri
from TesteTabele
where CodTest = @idtest AND CodTabel = @idtab

select @tabel = nume
from Tabele
where CodTabel = @idtab 

declare @i int
set @i=21
set @tabel ='I'+@tabel

while(@i<=@nrRanduri+20)
	Exec @tabel
end
GO
