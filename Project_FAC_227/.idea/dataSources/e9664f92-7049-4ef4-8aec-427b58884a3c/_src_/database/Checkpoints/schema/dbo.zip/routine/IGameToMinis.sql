
create procedure IGameToMinis
@id int
as
begin
	insert into Boardgames
	values (@id,'a',10)
	insert into Minis
	values (@id,'a','b')
	insert into GameToMinis
	values (@id,@id)
end
GO
