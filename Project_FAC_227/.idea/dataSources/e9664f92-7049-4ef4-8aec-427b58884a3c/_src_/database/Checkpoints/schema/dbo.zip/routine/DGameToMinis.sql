create procedure DGameToMinis
@id int
as
begin
	delete GameToMinis
	where idg>=@id
	delete Minis
	where idm>=@id
	delete Boardgames
	where idg>=@id
end
GO
