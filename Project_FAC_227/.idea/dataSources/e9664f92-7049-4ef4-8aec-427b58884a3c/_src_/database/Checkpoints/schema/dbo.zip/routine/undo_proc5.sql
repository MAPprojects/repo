CREATE PROCEDURE undo_proc5
AS
BEGIN
ALTER TABLE Telefon
DROP CONSTRAINT pk_Telefon
PRINT 'S-a sters PK-ul tabelei Telefon'
END
GO
