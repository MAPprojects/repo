create procedure DBoardgames
@id int
as
begin
	delete Boardgames
	where idg>=@id
end
GO
