CREATE PROCEDURE proc7
AS
BEGIN
ALTER TABLE Telefon
ADD CONSTRAINT fk_telefon FOREIGN KEY(idMan) REFERENCES Managers(idman)
PRINT 'S-au legat prin FK Tabelele Telefon-Managers prin idMan respectiv idman'
END
GO
