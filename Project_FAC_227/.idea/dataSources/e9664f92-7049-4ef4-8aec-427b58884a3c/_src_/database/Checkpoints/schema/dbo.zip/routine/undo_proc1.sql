CREATE PROCEDURE undo_proc1
AS
BEGIN
DROP TABLE Telefon
PRINT 'S-a sters tabelul Telefon'
END
GO
