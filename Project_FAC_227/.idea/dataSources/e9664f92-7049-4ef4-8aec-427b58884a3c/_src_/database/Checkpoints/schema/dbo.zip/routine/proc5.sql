CREATE PROCEDURE proc5
AS
BEGIN
ALTER TABLE Telefon
ADD CONSTRAINT pk_Telefon PRIMARY KEY(nrTel)
PRINT 'S-a adaugat PK la tabela Telefon - nrTel'
END
GO
