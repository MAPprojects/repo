create procedure DRuleBooks
@id int
as
begin
	delete RuleBooks
	where idr>=@id
	delete Boardgames
	where idg>=@id
end
GO
